package main

import (
	"github.com/gin-gonic/gin"
	"github.com/silenceper/wechat/v2"
	"github.com/sirupsen/logrus"
	"log"
	"time"
	"wxoa/okx"
	"wxoa/tool"
	"wxoa/wx"
)

func main() {
	var wc = wechat.NewWechat()
	wx.OfficialAccount = wx.NewExampleOfficialAccount(wc)
	logrus.SetLevel(logrus.ErrorLevel)
	go tick()
	r := gin.Default()
	gin.SetMode(gin.ReleaseMode)
	r.Any("serve", wx.OfficialAccount.Serve)
	r.GET("button", wx.OfficialAccount.Button)
	r.GET("position")
	r.GET("trade_records")
	err := r.Run(":8013")
	if err != nil {
		return
	}
}

var (
	lastPosM           = make(map[string]*okx.PosData)       //存储的最新仓位
	lastTradeRecordsM  = make(map[string][]*okx.TradeRecord) //存储的最新操作记录
	lastSendMsgRecordM = make(map[string]*okx.TradeRecord)   //存储上次推送的记录

)

func tick() {
	for range time.Tick(time.Minute) {
		records, err := okx.GetTradeRecords()
		if err != nil {
			log.Println("没有获取到记录,错误:", err)
			continue
		}
		if len(records) < 1 {
			continue
		}
		//保存最新数据
		msgM := saveRecords(records)
		if len(msgM) < 1 {
			continue
		}
		for _, msgRecord := range msgM {
			for _, openid := range wx.Users {
				wx.SendMsg(msgRecord, openid)
			}
		}
	}
	return
}

func saveRecords(records []*okx.TradeRecord) (msgM map[string]*okx.TradeRecord) {
	newRecordsM := make(map[string][]*okx.TradeRecord)
	msgM = make(map[string]*okx.TradeRecord)
	for _, record := range records {
		if newRecords, ok2 := newRecordsM[record.InstId]; ok2 {
			newRecords = append(newRecords, record)
		} else {
			newRecordsM[record.InstId] = []*okx.TradeRecord{record}
		}
	}
	for instId, tradeRecords := range newRecordsM {
		if lastRecords, ok := lastTradeRecordsM[instId]; ok {
			lastRecords = append(tradeRecords, lastRecords...)
			//去重
			var newLastRecords []*okx.TradeRecord
			var tm = make(map[string]struct{})
			for _, lr := range lastRecords {
				if _, o := tm[lr.InstId+lr.UTime]; !o {
					newLastRecords = append(newLastRecords, lr)
				}
			}
			lastTradeRecordsM[instId] = newLastRecords
			if len(lastTradeRecordsM[instId]) > 20 {
				lastTradeRecordsM[instId] = lastTradeRecordsM[instId][:20]
			}
		} else {
			lastTradeRecordsM[instId] = tradeRecords
		}
		newestRecord := lastTradeRecordsM[instId][0]
		//最近发送消息的数据
		if msgRecord, o2 := lastSendMsgRecordM[instId]; o2 {
			//如果是同向操作就不通知
			if msgRecord.InstId+msgRecord.PosSide+msgRecord.Side != newestRecord.InstId+newestRecord.PosSide+newestRecord.Side {
				msgM[instId] = newestRecord
				//更新最新发送给消息的
				lastSendMsgRecordM[instId] = newestRecord
			}
		} else {
			//五分钟之内
			if tool.UnixMilliToTime(newestRecord.UTime).Add(5 * time.Minute).After(time.Now()) {
				msgM[instId] = newestRecord
			}
			//如果该币种没有发送过消息更新最新发送给消息的
			lastSendMsgRecordM[instId] = newestRecord
		}
	}
	return
}
