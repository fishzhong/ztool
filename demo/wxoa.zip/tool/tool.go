package tool

import (
	"strconv"
	"time"
)

func UnixMilliToTime(s string) time.Time {
	temp, _ := strconv.ParseInt(s, 10, 64)
	return time.UnixMilli(temp)
}
