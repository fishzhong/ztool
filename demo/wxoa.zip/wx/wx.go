package wx

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/silenceper/wechat/v2"
	"github.com/silenceper/wechat/v2/cache"
	"github.com/silenceper/wechat/v2/officialaccount"
	"github.com/silenceper/wechat/v2/officialaccount/config"
	"github.com/silenceper/wechat/v2/officialaccount/menu"
	"github.com/silenceper/wechat/v2/officialaccount/message"
	"log"
	"net/http"
	"strconv"
	"time"
	"wxoa/okx"
)

var OfficialAccount *ExampleOfficialAccount
var Users = []string{
	"o2SLY6ArhSXfaUMKWIEC7DC-NrQ8", //张
	"o2SLY6OnPjrCemOyGZ2xsW3zEGf4", //我
}

// ExampleOfficialAccount 公众号操作样例
type ExampleOfficialAccount struct {
	wc              *wechat.Wechat
	officialAccount *officialaccount.OfficialAccount
}

func NewExampleOfficialAccount(wc *wechat.Wechat) *ExampleOfficialAccount {

	memory := cache.NewMemory()
	offCfg := &config.Config{
		AppID:     "wx466e9a8793ecf7ed",
		AppSecret: "0da278071fe575fa59de4795c7eb2e4d",
		Token:     "test",
		Cache:     memory,
		//EncodingAESKey: globalCfg.EncodingAESKey,
	}
	officialAccount := wc.GetOfficialAccount(offCfg)
	return &ExampleOfficialAccount{
		wc:              wc,
		officialAccount: officialAccount,
	}
}

var sideStr = map[string]string{
	"buy-long":   "买入开多",
	"buy-short":  "买入平空",
	"sell-long":  "卖出平多",
	"sell-short": "卖出开空",
}

// #0fd139
func SendMsg(b *okx.TradeRecord, openid string) {
	temp, _ := strconv.ParseInt(b.UTime, 10, 64)
	avgPx, _ := strconv.ParseFloat(b.AvgPx, 64)
	str := sideStr[fmt.Sprintf("%s-%s", b.Side, b.PosSide)]
	actStr := fmt.Sprintf("以均价%d %s %s倍", int(avgPx), str, b.Lever)
	_, err := OfficialAccount.officialAccount.GetTemplate().Send(&message.TemplateMessage{
		ToUser:     openid,
		TemplateID: "Fy2NnevsueVcK41F-0SG2rval9DONaC5AW_QFGmMMGY",
		Data: map[string]*message.TemplateDataItem{
			"inst":   {Value: b.InstFamily},
			"action": {Value: actStr},
			"time":   {Value: time.UnixMilli(temp).Format(time.DateTime)},
		},
	})
	if err != nil {
		log.Println("发送模板消息失败", openid)
	}
}

func (ex *ExampleOfficialAccount) Button(c *gin.Context) {
	buttons := []*menu.Button{
		menu.NewViewButton("baidu", "https://baidu.com"),
	}

	ex.officialAccount.GetMenu().SetMenu(buttons)
	c.String(http.StatusOK, "success")
}

// Serve 处理消息
func (ex *ExampleOfficialAccount) Serve(c *gin.Context) {
	// 传入request和responseWriter
	server := ex.officialAccount.GetServer(c.Request, c.Writer)
	server.SkipValidate(true)
	//设置接收消息的处理方法
	server.SetMessageHandler(func(msg *message.MixMessage) *message.Reply {
		//TODO
		//回复消息：演示回复用户发送的消息
		text := message.NewText(msg.Content)
		//log.Println("收到消息", text)
		return &message.Reply{MsgType: message.MsgTypeText, MsgData: text}
	})

	//处理消息接收以及回复
	err := server.Serve()
	if err != nil {
		return
	}
	//发送回复的消息
	err = server.Send()
	if err != nil {
		return
	}
}
