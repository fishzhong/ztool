package okx

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"time"
)

type TradeRecord struct {
	Alias      string `json:"alias"`
	AvgPx      string `json:"avgPx"`
	BaseName   string `json:"baseName"`
	CTime      string `json:"cTime"`
	FillTime   string `json:"fillTime"`
	InstFamily string `json:"instFamily"`
	InstId     string `json:"instId"`
	InstType   string `json:"instType"`
	Lever      string `json:"lever"`
	NickName   string `json:"nickName"`
	OrdId      string `json:"ordId"`
	OrdType    string `json:"ordType"`
	PosSide    string `json:"posSide"`
	Px         string `json:"px"`
	QuoteName  string `json:"quoteName"`
	Side       string `json:"side"`
	UTime      string `json:"uTime"`
	Uly        string `json:"uly"`
	UniqueName string `json:"uniqueName"`
}
type res struct {
	Code string         `json:"code"`
	Data []*TradeRecord `json:"data"`
	Msg  string         `json:"msg"`
}

func GetTradeRecords() (records []*TradeRecord, err error) {
	uri, err := url.Parse("http://127.0.0.1:1087")
	if err != nil {
		return
	}
	client := http.Client{Timeout: 10 * time.Second, Transport: &http.Transport{Proxy: http.ProxyURL(uri)}}
	now := time.Now()
	endModify := now.AddDate(0, 0, 1).Add(-time.Duration(now.Hour())*time.Hour - time.Duration(now.Minute())*time.Minute - time.Duration(now.Second()+1)*time.Second)
	startModify := endModify.AddDate(0, -3, -1).Add(time.Second)
	url0 := fmt.Sprintf(`https://www.okx.com/priapi/v5/ecotrade/public/trade-records?limit=5&startModify=%d&endModify=%d&uniqueName=563E3A78CDBAFB4E&t=%d`, startModify.UnixMilli()/1000*1000, endModify.UnixMilli()/1000*1000, now.UnixMilli())
	resp, err := client.Get(url0)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)
	var v res
	err = json.Unmarshal(data, &v)
	if err != nil {
		return
	}
	//读取切片最新数据传入abc
	if len(v.Data) == 0 {
		err = errors.New("没有数据")
		return
	}
	records = v.Data
	return
}

type PosRes struct {
	Code string `json:"code"`
	Data []struct {
		LongLever  string     `json:"longLever"`
		PosData    []*PosData `json:"posData"`
		ShortLever string     `json:"shortLever"`
	} `json:"data"`
	Msg string `json:"msg"`
}

type PosData struct {
	Alias    string `json:"alias"`
	AvgPx    string `json:"avgPx"`
	CTime    string `json:"cTime"`
	InstId   string `json:"instId"`
	InstType string `json:"instType"`
	Lever    string `json:"lever"`
	LiqPx    string `json:"liqPx"`
	MgnMode  string `json:"mgnMode"`
	Pos      string `json:"pos"`
	PosCcy   string `json:"posCcy"`
	PosSide  string `json:"posSide"`
	PosSpace string `json:"posSpace"`
	UplRatio string `json:"uplRatio"`
}

func GetPositionV2() (posData []*PosData, err error) {
	uri, err := url.Parse("http://127.0.0.1:1087")
	if err != nil {
		return
	}
	client := http.Client{Transport: &http.Transport{Proxy: http.ProxyURL(uri)}}
	now := time.Now()
	url0 := fmt.Sprintf(`https://www.okx.com/priapi/v5/ecotrade/public/positions-v2?limit=10&uniqueName=563E3A78CDBAFB4E&t=%d`, now.UnixMilli())
	resp, err := client.Get(url0)
	if err != nil {
		return
	}
	defer resp.Body.Close()
	data, _ := io.ReadAll(resp.Body)
	var v PosRes
	err = json.Unmarshal(data, &v)
	if err != nil {
		return
	}
	//读取切片最新数据传入abc
	if len(v.Data) == 0 {
		err = errors.New("没有数据")
		return
	}
	//posData =
	return
}
