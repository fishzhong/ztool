package main

import (
	"fmt"
	"testing"
	"time"
	"wxoa/okx"
)

func TestName(t *testing.T) {
	records := []*okx.TradeRecord{
		{Side: "buy", InstId: "BTC-USDT-SWAP", UTime: "1111", PosSide: "long"},
	}
	fmt.Println()
	L(saveRecords(records))

	records = []*okx.TradeRecord{
		{Side: "buy", InstId: "BTC-USDT-SWAP", UTime: "2222", PosSide: "long"},
	}
	fmt.Println()
	L(saveRecords(records))
	records = []*okx.TradeRecord{
		{Side: "sell", InstId: "BTC-USDT-SWAP", UTime: "3333", PosSide: "long"},
		{Side: "buy", InstId: "ETH-USDT-SWAP", UTime: "4444", PosSide: "long"},
	}
	fmt.Println()
	L(saveRecords(records))

}

func L(m map[string]*okx.TradeRecord) {
	if len(m) > 0 {
		for s, record := range m {
			fmt.Println("本次推送", s, record.Side, record.PosSide, record.UTime, record.InstId)
		}
	}
	fmt.Println(lastTradeRecordsM)
	for s, records := range lastTradeRecordsM {
		fmt.Println("最新数据", s, records[0].Side, records[0].PosSide, records[0].UTime, records[0].InstId)
	}
	//fmt.Println(lastSendRecordM)
	//for i, i2 := range lastSendRecordM {
	//	fmt.Println("存入的最新数据", i, i2.Side, i2.PosSide, i2.UTime, i2.InstId)
	//}

}

func TestName11(t *testing.T) {
	fmt.Println(time.Now().Format("15:04:05"))
}
